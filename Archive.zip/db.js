const mongoose = require("mongoose");

// Export the Mongoose connection function
const connectDB = () => {
  return mongoose.connect(process.env.MONGO_DB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
};

module.exports = connectDB;
