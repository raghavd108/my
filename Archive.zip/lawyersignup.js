const express = require("express");
const bcrypt = require("bcrypt");
const Lawyer = require("./models/lawyer"); // Import the Lawyer model
const multer = require("multer");

const router = express.Router();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(
      null,
      file.fieldname +
        "-" +
        uniqueSuffix +
        "." +
        file.originalname.split(".").pop()
    );
  },
});

const upload = multer({ storage: storage });

router.post(
  "/",
  upload.fields([
    { name: "photo", maxCount: 1 },
    { name: "aadharcard", maxCount: 1 },
    { name: "degree", maxCount: 1 },
    { name: "barcouncilcard", maxCount: 1 },
  ]),
  async (req, res) => {
    const {
      firstName,
      lastName,
      email,
      phoneNumber,
      gender,
      address,
      state,
      city,
      pincode,
      password,
    } = req.body;
    try {
      // Check if the email already exists
      const existingLawyer = await Lawyer.findOne({ email });
      if (existingLawyer) {
        // Instead of 409, return 400 (Bad Request)
        return res
          .status(400)
          .json({ message: "Invalid data or email already exists" });
      }

      // Hash the password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create a new lawyer
      const newLawyer = new Lawyer({
        firstName,
        lastName,
        email,
        phoneNumber,
        gender,
        address,
        state,
        city,
        pincode,
        password: hashedPassword,
        photo: req.files["photo"][0].path,
        aadharcard: req.files["aadharcard"][0].path,
        degree: req.files["degree"][0].path,
        barcouncilcard: req.files["barcouncilcard"][0].path,
      });
      await newLawyer.save();

      // Signup successful
      res.status(201).json({ message: "Signup successful" });

      // Logging
      console.log("New lawyer:", newLawyer);
    } catch (error) {
      console.error("Signup error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

module.exports = router;
