const config = {
  production: {
    SECRET: process.env.SECRET,
    DATABASE: process.env.MONGODB_URI,
  },
  default: {
    SECRET: '6741073deb7b5b00c28fbdeb8a5b5703a41ef8543e4af3225a80e1f35e5fdb4b',
    DATABASE: 'mongodb://localhost:27017/Users',
  },
};

exports.get = function get(env) {
  return config[env] || config.default;
};
