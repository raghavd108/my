const mongoose = require("mongoose");

const lawyerSchema = new mongoose.Schema({
  firstName: String,
  lastName: String,
  email: String,
  phoneNumber: String,
  gender: String,
  address: String,
  state: String,
  city: String,
  pincode: String,
  password: String,
  photo: String, // Store the path to the photo
  aadharcard: String, // Store the path to the Aadhar card
  degree: String, // Store the path to the degree
  barcouncilcard: String, // Store the path to the Bar Council card
});

const Lawyer = mongoose.model("Lawyer", lawyerSchema);

module.exports = Lawyer;
