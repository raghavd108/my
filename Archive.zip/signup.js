const express = require('express');
const bcrypt = require('bcrypt');
const User = require('./models/user');

const router = express.Router();

router.post('/', async (req, res) => {
  const { firstName, lastName, email, password } = req.body;
  try {
    // Check if the email already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(409).json({ message: 'Email already exists' });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user
    const newUser = new User({
      firstName,
      lastName,
      email,
      password: hashedPassword,
    });
    await newUser.save();

    // Store the user data in the session
    req.session.user = newUser;
    // Signup successful
    res.status(201).json({ message: 'Signup successful' });

    // Logging
    console.log('New user:', newUser);
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
