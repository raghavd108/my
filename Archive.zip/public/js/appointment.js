let userEmail;
const selectedAppointments = {}; // Data structure to store selected appointments

function openAppointmentPopup(lawyerEmail, lawyerName) {
  // Check if the user is logged in
  const isLoggedIn = sessionStorage.getItem("loggedInUser");

  if (isLoggedIn) {
    // User is logged in, proceed with the appointment booking
    userEmail = prompt("Please enter your email:");

    selectedLawyerEmail = lawyerEmail;
    const popup = document.getElementById("appointmentPopup");
    const selectedDate = document.getElementById("selectedDate");
    const selectedTime = document.getElementById("selectedTime");
    const purpose = document.getElementById("purpose");

    // Clear any previous selections
    selectedDate.value = "";
    selectedTime.value = "";
    purpose.value = "";

    // Display the popup only when the button is clicked
    popup.style.display = "block";

    // Set the lawyer's name in the popup heading
    const popupHeading = popup.querySelector("h2");
    popupHeading.textContent = `Select Date and Time for Appointment with ${lawyerName}`;
  } else {
    // User is not logged in, prompt for login
    alert("Please log in to book an appointment.");
    // You can redirect to the login page or handle the login process here
  }
}

function closeAppointmentPopup() {
  const popup = document.getElementById("appointmentPopup");
  popup.style.display = "none";
}

function isAppointmentTaken(date, time, lawyerEmail) {
  // Check if the selected appointment is already taken
  return (
    selectedAppointments[date] &&
    selectedAppointments[date][time] &&
    selectedAppointments[date][time] !== lawyerEmail
  );
}

function submitAppointment() {
  const selectedDate = document.getElementById("selectedDate").value;
  const selectedTime = document.getElementById("selectedTime").value;
  const purpose = document.getElementById("purpose").value;

  // Assuming you have a fixed appointment fee, e.g., 1000
  const appointmentFee = 199;

  // Open the payment popup with the fixed amount
  openPaymentPopup(appointmentFee);

  if (selectedDate && selectedTime && selectedLawyerEmail && purpose) {
    // Check if the selected appointment is already taken
    if (isAppointmentTaken(selectedDate, selectedTime, selectedLawyerEmail)) {
      alert(
        "This appointment slot is already booked. Please choose another time."
      );
      return;
    }

    // Mark the appointment as taken
    if (!selectedAppointments[selectedDate]) {
      selectedAppointments[selectedDate] = {};
    }
    selectedAppointments[selectedDate][selectedTime] = selectedLawyerEmail;

    // Send appointment details to the server
    fetch("/send-appointment-email", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        lawyerEmail: selectedLawyerEmail,
        date: selectedDate,
        time: selectedTime,
        userEmail: userEmail,
        purpose: purpose, // Include purpose in the data sent to the server
      }),
    })
      .then((response) => {
        // Handle success or error
        if (response.ok) {
          console.log("Appointment details sent successfully");
          alert(
            "Appointment booked successfully! The lawyer will connect with you soon. Check your email."
          );

          // Update the appointment button text
          const appointmentButton = document.getElementById("appointment-btn");
          if (appointmentButton) {
            appointmentButton.textContent = "Appointment Booked";
            appointmentButton.disabled = true; // Disable the button after booking
          }
        } else {
          console.log("Failed to send appointment details");
          alert("Failed to book the appointment. Please try again.");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert(
          "An error occurred while booking the appointment. Please try again."
        );
      });

    closeAppointmentPopup();
  } else {
    alert(
      "Please select a date, time, and provide a purpose for the appointment"
    );
  }
}
// Function to open payment popup
function openPaymentPopup(amount) {
  document.getElementById("amountValue").innerText = amount;
  document.getElementById("paymentPopup").style.display = "block";
}

// Function to close payment popup
function closePaymentPopup() {
  document.getElementById("paymentPopup").style.display = "none";
}

function makePayment() {
  const amount = document.getElementById("amountValue").innerText;

  // Fetch Razorpay key from the server
  fetch("/paymentRouter/get-razorpay-key")
    .then((keyResponse) => keyResponse.json())
    .then((keyData) => {
      const options = {
        key: keyData.razorpay_key,
        amount: amount * 100,
        currency: "INR",
        name: "Vidhigyah.com",
        description: "Appointment Fee",
        handler: function (response) {
          alert(
            "Payment Successful! Transaction ID: " +
              response.razorpay_payment_id
          );
          closePaymentPopup();
        },
        prefill: {
          name: "User Name",
          email: userEmail,
        },
        notes: {
          appointment_id: "YOUR_APPOINTMENT_ID",
        },
        theme: {
          color: "#528FF0",
        },
      };

      const razorpayInstance = new Razorpay(options);
      razorpayInstance.open();
    })
    .catch((error) => {
      console.error("Error:", error);
      alert("Failed to initiate payment. Please try again.");
    });
}
