var stateCityMapping = {
  "Andhra Pradesh": [
    "Visakhapatnam",
    "Vijayawada",
    "Guntur",
    "Nellore",
    "Kurnool",
    "Kadapa",
    "Rajahmundry",
    "Kakinada",
    "Tirupati",
    "Anantapur",
  ],
  "Arunachal Pradesh": [
    "Itanagar",
    "Naharlagun",
    "Pasighat",
    "Namsai",
    "Changlang",
    "Roing",
    "Tezu",
    "Ziro",
    "Bomdila",
    "Tawang",
  ],
  Assam: [
    "Guwahati",
    "Silchar",
    "Dibrugarh",
    "Jorhat",
    "Nagaon",
    "Tinsukia",
    "Tezpur",
    "Sivasagar",
    "Goalpara",
    "Karimganj",
  ],
  Bihar: [
    "Patna",
    "Gaya",
    "Bhagalpur",
    "Muzaffarpur",
    "Darbhanga",
    "Arrah",
    "Bihar Sharif",
    "Purnia",
    "Begusarai",
    "Katihar",
  ],
  Chhattisgarh: [
    "Raipur",
    "Bhilai",
    "Durg",
    "Raigarh",
    "Rajnandgaon",
    "Jagdalpur",
    "Korba",
    "Bilaspur",
    "Ambikapur",
    "Mahasamund",
  ],
  Goa: [
    "Panaji",
    "Margao",
    "Vasco da Gama",
    "Ponda",
    "Mapusa",
    "Bicholim",
    "Curchorem",
    "Cuncolim",
    "Valpoi",
    "Sanguem",
  ],
  Gujarat: [
    "Ahmedabad",
    "Surat",
    "Vadodara",
    "Rajkot",
    "Bhavnagar",
    "Jamnagar",
    "Junagadh",
    "Gandhinagar",
    "Nadiad",
    "Morbi",
  ],
  Haryana: [
    "Faridabad",
    "Gurgaon",
    "Panipat",
    "Ambala",
    "Yamunanagar",
    "Rohtak",
    "Hisar",
    "Karnal",
    "Sonipat",
    "Panchkula",
  ],
  "Himachal Pradesh": [
    "Shimla",
    "Mandi",
    "Solan",
    "Dharamshala",
    "Una",
    "Bilaspur",
    "Kullu",
    "Chamba",
    "Hamirpur",
    "Nahan",
  ],
  Jharkhand: [
    "Ranchi",
    "Jamshedpur",
    "Dhanbad",
    "Bokaro",
    "Deoghar",
    "Hazaribagh",
    "Giridih",
    "Ramgarh",
    "Medininagar",
    "Chirkunda",
  ],
  Karnataka: [
    "Bengaluru",
    "Mysuru",
    "Hubballi",
    "Mangaluru",
    "Belagavi",
    "Shivamogga",
    "Ballari",
    "Davangere",
    "Kalaburagi",
    "Tumakuru",
  ],
  Kerala: [
    "Thiruvananthapuram",
    "Kochi",
    "Kozhikode",
    "Thrissur",
    "Malappuram",
    "Kollam",
    "Palakkad",
    "Alappuzha",
    "Kannur",
    "Kottayam",
  ],
  "Madhya Pradesh": [
    "Bhopal",
    "Indore",
    "Jabalpur",
    "Gwalior",
    "Ujjain",
    "Sagar",
    "Dewas",
    "Satna",
    "Ratlam",
    "Rewa",
  ],
  Maharashtra: [
    "Mumbai",
    "Pune",
    "Nagpur",
    "Thane",
    "Nashik",
    "Kalyan-Dombivli",
    "Vasai-Virar",
    "Aurangabad",
    "Solapur",
    "Navi Mumbai",
  ],
  Manipur: [
    "Imphal",
    "Thoubal",
    "Bishnupur",
    "Churachandpur",
    "Senapati",
    "Ukhrul",
    "Kakching",
    "Jiribam",
    "Tamenglong",
    "Kangpokpi",
  ],
  Meghalaya: [
    "Shillong",
    "Tura",
    "Nongstoin",
    "Jowai",
    "Baghmara",
    "Williamnagar",
    "Nongpoh",
    "Resubelpara",
    "Mairang",
    "Mawkyrwat",
  ],
  Mizoram: [
    "Aizawl",
    "Lunglei",
    "Saiha",
    "Champhai",
    "Serchhip",
    "Kolasib",
    "Lawngtlai",
    "Mamit",
    "Saitual",
    "Khawzawl",
  ],
  Nagaland: [
    "Kohima",
    "Dimapur",
    "Mokokchung",
    "Tuensang",
    "Wokha",
    "Zunheboto",
    "Phek",
    "Peren",
    "Mon",
    "Longleng",
  ],
  Odisha: [
    "Bhubaneswar",
    "Cuttack",
    "Rourkela",
    "Brahmapur",
    "Sambalpur",
    "Puri",
    "Baleshwar",
    "Baripada",
    "Bhadrak",
    "Balangir",
  ],
  Punjab: [
    "Ludhiana",
    "Amritsar",
    "Jalandhar",
    "Patiala",
    "Bathinda",
    "Pathankot",
    "Mohali",
    "Hoshiarpur",
    "Batala",
    "Moga",
  ],
  Rajasthan: [
    "Jaipur",
    "Jodhpur",
    "Kota",
    "Bikaner",
    "Ajmer",
    "Udaipur",
    "Bhilwara",
    "Alwar",
    "Bharatpur",
    "Sikar",
  ],
  Sikkim: [
    "Gangtok",
    "Namchi",
    "Gyalshing",
    "Rangpo",
    "Soreng",
    "Mangan",
    "Naya Bazar",
    "Ravangla",
    "Singtam",
    "Jorethang",
  ],
  "Tamil Nadu": [
    "Chennai",
    "Coimbatore",
    "Madurai",
    "Tiruchirappalli",
    "Salem",
    "Tirunelveli",
    "Tiruppur",
    "Erode",
    "Vellore",
    "Thoothukudi",
  ],
  Telangana: [
    "Hyderabad",
    "Warangal",
    "Nizamabad",
    "Khammam",
    "Karimnagar",
    "Ramagundam",
    "Mahbubnagar",
    "Nalgonda",
    "Adilabad",
    "Suryapet",
  ],
  Tripura: [
    "Agartala",
    "Udaipur",
    "Dharmanagar",
    "Kailasahar",
    "Belonia",
    "Teliamura",
    "Khowai",
    "Ambassa",
    "Kamalpur",
    "Sonamura",
  ],
  "Uttar Pradesh": [
    "Lucknow",
    "Kanpur",
    "Ghaziabad",
    "Agra",
    "Meerut",
    "Varanasi",
    "Prayagraj",
    "Bareilly",
    "Aligarh",
    "Moradabad",
  ],
  Uttarakhand: [
    "Dehradun",
    "Haridwar",
    "Roorkee",
    "Haldwani",
    "Rudrapur",
    "Kashipur",
    "Rishikesh",
    "Kotdwara",
    "Srinagar",
    "Nainital",
  ],
  "West Bengal": [
    "Kolkata",
    "Howrah",
    "Asansol",
    "Siliguri",
    "Durgapur",
    "Bardhaman",
    "Malda",
    "Baharampur",
    "Habra",
    "Kharagpur",
  ],
  "Andaman and Nicobar Islands": [
    "Port Blair",
    "Car Nicobar",
    "Bamboo Flat",
    "Garacharma",
    "Campbell Bay",
    "Mayabunder",
    "Diglipur",
    "Rangat",
    "Nimbudera",
    "Kadamtala",
  ],
  Chandigarh: ["Chandigarh"],
  "Dadra and Nagar Haveli": [
    "Silvassa",
    "Amli",
    "Dadra",
    "Naroli",
    "Rakholi",
    "Dahikhed",
    "Khadoli",
    "Kanadi",
    "Kharadpada",
    "Athola",
  ],
  "Daman and Diu": ["Daman", "Diu"],
  Delhi: ["Delhi"],
  Lakshadweep: [
    "Kavaratti",
    "Andrott",
    "Agatti",
    "Amini",
    "Kalpeni",
    "Kadmat",
    "Minicoy",
    "Kiltan",
    "Chetlat",
    "Bitra",
  ],
  Puducherry: ["Puducherry", "Karaikal", "Yanam", "Mahe"],
};

var selectedLocation = {
  state: "",
  city: "",
};

window.addEventListener("load", function () {
  var popup = document.getElementById("popup");
  popup.style.display = "flex";
  updateCityOptions(); // Update city options initially
});
var storedLocation = localStorage.getItem("selectedLocation");
if (storedLocation) {
  selectedLocation = JSON.parse(storedLocation);
  updateSelectedLocation(); // Update the selected location on page load
}
// Check if the popup has already been displayed during the current session
var popupDisplayed = sessionStorage.getItem("popupDisplayed");

// Display the popup if it hasn't been displayed during the current session
if (!popupDisplayed) {
  var popup = document.getElementById("popup");
  popup.style.display = "flex";

  // Set a flag in sessionStorage to indicate that the popup has been displayed
  sessionStorage.setItem("popupDisplayed", "true");
}

function updateCityOptions() {
  var stateSelect = document.getElementById("state");
  var citySelect = document.getElementById("city");
  var selectedState = stateSelect.value;

  // Clear previous city options
  citySelect.innerHTML = "";

  // Add new city options based on the selected state
  var cities = stateCityMapping[selectedState] || [];
  for (var i = 0; i < cities.length; i++) {
    var option = document.createElement("option");
    option.value = cities[i];
    option.text = cities[i];
    citySelect.appendChild(option);
  }
}
function openStatePopup() {
  var popup = document.getElementById("popup");
  popup.style.display = "flex";
}

function updateSelectedLocation() {
  var stateSelect = document.getElementById("state");
  var citySelect = document.getElementById("city");

  // Update the selectedLocation object
  selectedLocation.state = stateSelect.value;
  selectedLocation.city = citySelect.value;

  // Display the selected location
  var selectedLocationDiv = document.getElementById("selectedLocation");
  selectedLocationDiv.textContent =
    "Selected Location: " +
    selectedLocation.city +
    ", " +
    selectedLocation.state;
  selectedLocationDiv.style.display = "block";

  // Filter the lawyers based on the selected location
  filterLawyers();

  // Hide the popup
  var popup = document.getElementById("popup");
  popup.style.display = "none";
  localStorage.setItem("selectedLocation", JSON.stringify(selectedLocation));
}

function filterLawyers() {
  var lawyerProfiles = document.getElementsByClassName("lawyer-profile");

  // Show all lawyer profiles initially
  for (var i = 0; i < lawyerProfiles.length; i++) {
    lawyerProfiles[i].style.display = "block";
  }

  // If a state is selected, hide lawyer profiles that don't match the state
  if (selectedLocation.state !== "") {
    for (var i = 0; i < lawyerProfiles.length; i++) {
      var state = lawyerProfiles[i].getAttribute("data-state");
      if (state !== selectedLocation.state) {
        lawyerProfiles[i].style.display = "none";
      }
    }
  }

  // If a city is selected, hide lawyer profiles that don't match the city
  if (selectedLocation.city !== "") {
    for (var i = 0; i < lawyerProfiles.length; i++) {
      var city = lawyerProfiles[i].getAttribute("data-city");
      if (city !== selectedLocation.city) {
        lawyerProfiles[i].style.display = "none";
      }
    }
  }
}

let selectedLawyerEmail; // Declare the selected lawyer's email variable

// Wait for the DOM content to load
document.addEventListener("DOMContentLoaded", () => {
  const popup = document.getElementById("appointmentPopup");
  popup.style.display = "none"; // Initially hide the appointment popup

  // Add event listener for state select element
  const stateSelect = document.getElementById("state");
  stateSelect.addEventListener("change", filterLawyers);

  // Add event listener for city select element
  const citySelect = document.getElementById("city");
  citySelect.addEventListener("change", filterLawyers);
});
