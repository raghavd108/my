// Function to toggle between signup and signin forms
function toggleForm() {
  var signUpForm = document.getElementById("lawyerSignUpForm"); // Corrected ID
  var signInForm = document.getElementById("lawyersignInForm");

  signUpForm.style.display =
    signUpForm.style.display === "none" ? "block" : "none";
  signInForm.style.display =
    signInForm.style.display === "none" ? "block" : "none";
  document.getElementById("message").textContent = "";
}

// In handleLoginSuccess function, use localStorage instead of sessionStorage
function handleLoginSuccess(lawyer, token) {
  console.log("Logged in lawyer:", lawyer);
  showMessage("Login successful", false);
  // Store user data and token in sessionStorage
  sessionStorage.setItem("loggedInLawyer", JSON.stringify(lawyer));
  sessionStorage.setItem("lawyer_token", token);
  updateNavigation(true);
  showDashboard(lawyer);
}

// Function to handle signup form submission
// Function to handle signup form submission
document
  .getElementById("lawyerSignUpForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    // Retrieve form data
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var email = document.getElementById("signupEmail").value;
    var phoneNumber = document.getElementById("phoneNumber").value;
    var gender = document.getElementById("gender").value;
    var address = document.getElementById("address").value;
    var state = document.getElementById("state").value;
    var city = document.getElementById("city").value;
    var pincode = document.getElementById("pincode").value;
    var password = document.getElementById("signupPassword").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    var photo = document.getElementById("photo").files[0];
    var aadharcard = document.getElementById("aadharcard").files[0];
    var degree = document.getElementById("degree").files[0];
    var barcouncilcard = document.getElementById("barcouncilcard").files[0];

    if (password !== confirmPassword) {
      showMessage("Passwords do not match.", true);
      return;
    }

    // Create form data object
    var formData = new FormData();
    formData.append("firstName", firstName);
    formData.append("lastName", lastName);
    formData.append("email", email);
    formData.append("phoneNumber", phoneNumber);
    formData.append("gender", gender);
    formData.append("address", address);
    formData.append("state", state);
    formData.append("city", city);
    formData.append("pincode", pincode);
    formData.append("password", password);
    formData.append("photo", photo);
    formData.append("aadharcard", aadharcard);
    formData.append("degree", degree);
    formData.append("barcouncilcard", barcouncilcard);

    // Send the signup data to the server
    axios
      .post("/lawyersignup", formData)
      .then((response) => {
        if (response.status === 201) {
          showMessage("Signup successful", false);
          // Optionally, you can automatically log in the user after successful signup
          handleLoginSuccess(response.data.lawyer, response.data.token);
        } else {
          showMessage("Signup failed", true);
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        showMessage("Signup failed", true);
      });
  });

// Function to handle signin form submission
document
  .getElementById("lawyersignInForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    // Retrieve form data
    var email = document.getElementById("signInEmail").value;
    var password = document.getElementById("signInPassword").value;

    var lawyerData = {
      email: email,
      password: password,
    };

    // Send the login data to the server
    axios
      .post("/lawyersignin", lawyerData)
      .then((response) => {
        if (response.status === 200) {
          var data = response.data;
          handleLoginSuccess(data.lawyer, data.token); // Pass the user and token to the success handler
        } else {
          showMessage("Login failed", true);
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        showMessage("Login failed", true);
      });
  });

document
  .getElementById("lawyerSignOutBtn")
  .addEventListener("click", function () {
    axios
      .post("/lawyersignout")
      .then((response) => {
        if (response.status === 200) {
          showMessage("Sign-out successful", false);
          sessionStorage.removeItem("loggedInLawyer");
          localStorage.removeItem("token"); // Remove the JWT token from local storage
          // Remove user data and token from sessionStorage
          sessionStorage.removeItem("loggedInLawyer");
          sessionStorage.removeItem("token");
          updateNavigation(false);
          showLoginForm();
        } else {
          showMessage("Sign-out failed", true);
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        showMessage("Sign-out failed", true);
      });
  });

// Function to display messages
function showMessage(message, isError) {
  var messageElement = document.getElementById("message");
  messageElement.textContent = message;
  messageElement.style.color = isError ? "red" : "green";

  // Show the message for a second and then hide it
  setTimeout(function () {
    messageElement.textContent = "";
  }, 1000);
}

// Function to update navigation based on login status
function updateNavigation(isLoggedIn) {
  var signInForm = document.getElementById("lawyersignInForm");
  var dashboard = document.getElementById("dashboard");

  signInForm.style.display = isLoggedIn ? "none" : "block";
  dashboard.style.display = isLoggedIn ? "block" : "none";
}

// Function to show dashboard
function showDashboard(lawyer) {
  var userFullNameElement = document.getElementById("lawyerFullName");
  var userEmailElement = document.getElementById("lawyerEmail");
  var lawyerPhotoElement = document.getElementById("lawyerPhoto");

  if (lawyer) {
    if (lawyer.firstName && lawyer.lastName) {
      userFullNameElement.textContent =
        lawyer.firstName + " " + lawyer.lastName;
    } else {
      userFullNameElement.textContent = "Unknown User";
    }

    if (lawyer.email) {
      userEmailElement.textContent = lawyer.email;
    } else {
      userEmailElement.textContent = "Unknown Email";
    }

    if (lawyer.photo) {
      lawyerPhotoElement.src = lawyer.photo;
      lawyerPhotoElement.style.maxWidth = "200px";
      lawyerPhotoElement.style.maxHeight = "200px";
    } else {
      lawyerPhotoElement.src = ""; // Set the source to an empty string if no photo is available
    }
  } else {
    userFullNameElement.textContent = "Unknown User";
    userEmailElement.textContent = "Unknown Email";
    lawyerPhotoElement.src = ""; // Set the source to an empty string if no lawyer data is available
  }
}

function showLoginForm() {
  var signInForm = document.getElementById("lawyersignInForm");
  signInForm.style.display = "block";
}

// Check if the user is already logged in and has a token
var loggedInLawyer = sessionStorage.getItem("loggedInLawyer");
var token = sessionStorage.getItem("token");

// If not found in sessionStorage, check in localStorage
if (!loggedInLawyer || !token) {
  loggedInLawyer = localStorage.getItem("loggedInLawyer");
  token = localStorage.getItem("token");
}

if (loggedInLawyer && token) {
  try {
    loggedInLawyer = JSON.parse(loggedInLawyer);
    if (loggedInLawyer && typeof loggedInLawyer === "object") {
      handleLoginSuccess(loggedInLawyer, token);
    } else {
      throw new Error("Invalid loggedInLawyer data");
    }
  } catch (error) {
    console.error("Error parsing user data:", error);
    console.error("Original loggedInLawyer:", loggedInLawyer);
    localStorage.removeItem("loggedInLawyer");
    sessionStorage.removeItem("loggedInLawyer"); // Also remove from sessionStorage
    showLoginForm();
  }
} else {
  showLoginForm();
}
