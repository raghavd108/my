const nodemailer = require("nodemailer");
require("dotenv").config();

function sendEmail(req, res) {
  const { lawyerEmail, date, time, purpose } = req.body;

  // Prompt the user for their email
  const userEmail = req.body.userEmail || prompt("Please enter your email:");

  if (!userEmail) {
    return res.status(400).json({ message: "User email is required." });
  }

  // Replace the following with your SMTP server settings
  const transporter = nodemailer.createTransport({
    service: "Gmail", // Use a secure Gmail account for email sending
    auth: {
      user: "vidhigyah.com@gmail.com", // Use a separate secure Gmail account for email sending
      pass: process.env.GMAIL_PASSWORD, // Use the password for the secure Gmail account
    },
  });

  const mailOptions = {
    from: userEmail, // Set the user's email as the "from" address
    to: lawyerEmail,
    subject: "Appointment Booking Confirmation",
    text: `Dear lawyer, you have an appointment on ${date} at ${time} with the user having email: ${userEmail}.Reason to connect with you is:${purpose}`,
  };

  // Send the email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error("Error sending email:", error);
      res.status(500).json({ message: "Failed to send the appointment email" });
    } else {
      console.log("Appointment email sent:", info.response);
      res.status(200).json({ message: "Appointment email sent successfully" });
    }
  });
}

module.exports = { sendEmail };
