const { OAuth2Client } = require('google-auth-library');

const client = new OAuth2Client('YOUR_GOOGLE_CLIENT_ID');

async function verifyToken(req, res) {
  const { token } = req.body;

  try {
    // Verify the token using the client ID
    const ticket = await client.verifyIdToken({
      idToken: token,
      audience: 'YOUR_GOOGLE_CLIENT_ID',
    });

    // Get user information from the verified token
    const payload = ticket.getPayload();
    const userId = payload.sub;
    const email = payload.email;

    // You can perform additional operations here, such as
    // storing user information in your database or creating a session

    // Return the user information as a response
    res.json({ userId, email });
  } catch (error) {
    console.error('Token verification failed:', error);
    res.status(400).json({ error: 'Token verification failed' });
  }
}

module.exports = {
  verifyToken,
};
