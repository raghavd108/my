const express = require("express");
const http = require("http");
const mongoose = require("mongoose");
const connectDB = require("./db");
const path = require("path");
const session = require("express-session");
const { verifyToken } = require("./tokenVerification");
const emailController = require("./email");
const signupRoutes = require("./signup");
const signinRoutes = require("./signin");
const lawyersignupRoutes = require("./lawyersignup");
const lawyersigninRoutes = require("./lawyersignin");
const lawyersignoutRoutes = require("./lawyersignout");
const signoutRoutes = require("./signout");
const initializeSocketServer = require("./socketServer");
const paymentRouter = require("./paymentRouter");

const app = express();
const port = process.env.PORT || 3000;
const server = http.createServer(app);

// Connect to MongoDB
connectDB()
  .then(() => {
    console.log("Connected to MongoDB");
    // Start the server after the successful database connection
    server.listen(port, () => {
      console.log(`Server is running at port ${port}`);
    });
    initializeSocketServer(server);
  })
  .catch((err) => {
    console.error("MongoDB connection error:", err);
    process.exit(1); // Terminate the application if the connection fails
  });

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
app.use("/paymentRouter", paymentRouter);

app.use(
  session({
    secret: "6741073deb7b5b00c28fbdeb8a5b5703a41ef8543e4af3225a80e1f35e5fdb4b",
    resave: false,
    saveUninitialized: true,
  })
);

app.use("/lawyersignup", lawyersignupRoutes);
app.use("/lawyersignin", lawyersigninRoutes);
app.use("/lawyersignout", lawyersignoutRoutes);
app.use("/signup", signupRoutes);
app.use("/signin", signinRoutes);
app.use("/signout", signoutRoutes);
// Add this line to serve static files from the uploads directory
app.use("/uploads", express.static("uploads"));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.post("/verify_token", verifyToken);

// Handle the appointment form submission
app.post("/send-appointment-email", emailController.sendEmail);

mongoose.connection.on("error", (error) => {
  console.error("Mongoose connection error:", error);
});

app.on("error", (error) => {
  console.error("Express app error:", error);
});
