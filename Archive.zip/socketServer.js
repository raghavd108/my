// socketServer.js

const socketIO = require("socket.io");

function initializeSocketServer(httpServer) {
  const io = socketIO(httpServer, {
    cors: {
      origin: "http://127.0.0.1:5500",
      methods: ["GET", "POST"],
    },
  });

  const users = {};

  io.on("connection", (socket) => {
    socket.on("new-user-joined", (name) => {
      console.log("new user", name);
      users[socket.id] = name;
      socket.broadcast.emit("user-joined", name);
    });

    socket.on("send", (message) => {
      // Broadcast the message to all users except the sender
      socket.broadcast.emit("receive", {
        message: message,
        name: users[socket.id],
      });
    });

    socket.on("disconnect", () => {
      socket.broadcast.emit("left", users[socket.id]);
      delete users[socket.id];
    });
  });
}

module.exports = initializeSocketServer;
